import math
r = float(input("Moi ban nhap ban kinh r: "))
cv = 2 * math.pi * r
dt = math.pi * r**2
print(f"Chu vi hinh tron: {cv:.2f}")
print(f"Dien tich hinh tron: {dt:.2f}")